Colorizing Console Streams
==========================

``ColorizingStreamHandler`` is a handler which allows colorizing of console
streams, described here_ in more detail. 

.. _here: http://plumberjack.blogspot.com/2010/12/colorizing-logging-output-in-terminals.html

.. automodule:: logutils.colorize
    :members:

