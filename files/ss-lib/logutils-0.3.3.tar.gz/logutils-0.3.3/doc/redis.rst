Working with Redis queues
=========================

:class:`~logutils.queue.QueueHandler` and :class:`~logutils.queue.QueueListener` classes are provided to facilitate interfacing with Redis.

.. autoclass:: logutils.redis.RedisQueueHandler
    :members:

.. autoclass:: logutils.redis.RedisQueueListener
    :members:

