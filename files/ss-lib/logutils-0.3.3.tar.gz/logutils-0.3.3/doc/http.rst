Working with web sites
======================

**N.B.** The :class:`~logutils.http.HTTPHandler` class has been present in the
:mod:`logging` package since the first release, but was enhanced for Python
3.2 to add options for secure connections and user credentials. You may wish
to use this version with earlier Python releases.

.. automodule:: logutils.http
    :members:

