TODO
====

* Switch to proper test skips once Django 1.3 is minimum supported.
